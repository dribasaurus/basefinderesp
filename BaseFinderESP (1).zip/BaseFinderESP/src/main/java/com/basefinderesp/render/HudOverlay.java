package com.basefinderesp.render;

import com.basefinderesp.BaseFinderEspClient;
import com.basefinderesp.config.ModConfig;
import com.basefinderesp.detect.Detection;
import com.basefinderesp.scan.BlockScanner;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.List;

public final class HudOverlay {
    private record Line(String text, int color) {}

    private static final int SHOWN = 5;

    private HudOverlay() {}

    public static void init() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(BaseFinderEspClient.MOD_ID, "overlay"),
                HudOverlay::render);
    }

    private static void render(GuiGraphicsExtractor g, DeltaTracker deltaTracker) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.showHud) return;

        Minecraft mc = Minecraft.getInstance();
        Font font = mc.font;

        List<Line> lines = new ArrayList<>();
        lines.add(new Line("BASE FINDER ESP", 0xFFFFE53B));
        lines.add(new Line("Scanner: " + onOff(cfg.scannerEnabled) + "  ESP: " + onOff(cfg.espEnabled)
                + "  Radius: " + cfg.radius + " blocks  Detected: " + BlockScanner.count(), 0xFFFFFFFF));
        if (BaseFinderEspClient.lunarSuspected) {
            lines.add(new Line("! Lunar Client suspected: Fabric mods may not load or render here", 0xFFFF5555));
        }

        List<BlockScanner.Row> rows = BlockScanner.rows();
        if (!rows.isEmpty()) {
            lines.add(new Line("Recent detections:", 0xFFAAAAAA));
            for (int i = 0; i < Math.min(SHOWN, rows.size()); i++) {
                BlockScanner.Row row = rows.get(i);
                Detection d = row.detection();
                StringBuilder sb = new StringBuilder("  ").append(d.name);
                if (cfg.showDistance) sb.append(" \u2014 ").append(Math.round(row.distance())).append(" blocks");
                if (cfg.showCoords) {
                    BlockPos p = d.blockPos();
                    sb.append("  [").append(p.getX()).append(", ").append(p.getY()).append(", ").append(p.getZ()).append("]");
                }
                lines.add(new Line(sb.toString(), 0xFF000000 | cfg.color(d.category)));
            }
        }

        int x = 8, y = 8, width = 0;
        for (Line l : lines) width = Math.max(width, font.width(l.text()));
        int height = lines.size() * (font.lineHeight + 2);

        g.fill(x - 4, y - 4, x + width + 4, y + height + 2, 0x90000000);
        for (Line l : lines) {
            g.text(font, l.text(), x, y, l.color(), true);
            y += font.lineHeight + 2;
        }
    }

    private static String onOff(boolean b) { return b ? "ON" : "OFF"; }
}
