package com.basefinderesp.render;

import com.basefinderesp.config.ModConfig;
import com.basefinderesp.detect.Detection;
import com.basefinderesp.scan.BlockScanner;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;

/**
 * ISOLATED RENDER CLASS. This is the part most likely to need a tweak for 26.1.2.
 * It uses vanilla Gizmos (outline + translucent fill, "always on top" = through walls)
 * submitted from Fabric's BEFORE_GIZMOS level render event.
 *
 * Verify against the 26.1.2 sources if the build fails here:
 *  - LevelRenderEvents.BEFORE_GIZMOS callback parameter list
 *  - Gizmos.cuboid(AABB, GizmoStyle) / GizmoStyle.strokeAndFill(int, float, int) / setAlwaysOnTop()
 *
 * Floating text labels (name/coords/distance above each box) are NOT drawn in-world; that
 * information is shown in the HUD panel instead (see HudOverlay).
 */
public final class EspRenderer {
    private EspRenderer() {}

    public static void init() {
        LevelRenderEvents.BEFORE_GIZMOS.register(context -> render());
    }

    private static void render() {
        ModConfig cfg = ModConfig.get();
        if (!cfg.espEnabled || !cfg.scannerEnabled) return;

        for (BlockScanner.Row row : BlockScanner.rows()) {
            Detection d = row.detection();
            int rgb = cfg.color(d.category);
            int stroke = 0xFF000000 | rgb;
            int fill = 0x33000000 | rgb;
            var gizmo = Gizmos.cuboid(d.box(), GizmoStyle.strokeAndFill(stroke, 2.0f, fill));
            if (cfg.throughWalls) {
                gizmo.setAlwaysOnTop();
            }
        }
    }
}
