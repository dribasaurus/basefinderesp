package com.basefinderesp.gui;

import com.basefinderesp.config.ModConfig;
import com.basefinderesp.detect.BlockClassifier;
import com.basefinderesp.detect.Category;
import com.basefinderesp.scan.BlockScanner;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.Supplier;

/** Button-based config menu. Colors cycle through presets; exact hex values can be set in the JSON file. */
public final class ConfigScreen extends Screen {
    private static final int[] PALETTE = {
            0xFF3B3B, 0xFF9F1A, 0xFFE53B, 0x3BFF6B, 0x2DE2E6, 0x3B7BFF, 0xB04CFF, 0xFF6BD6, 0xFFFFFF
    };

    private final Screen parent;

    public ConfigScreen(Screen parent) {
        super(Component.literal("BaseFinder ESP Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        ModConfig cfg = ModConfig.get();
        int colW = 150, gap = 8, step = 22;
        int cx = this.width / 2;
        int left = cx - colW - gap / 2;
        int right = cx + gap / 2;
        int fullW = colW * 2 + gap;
        int y = Math.max(24, this.height / 2 - 125);

        toggle(left, y, colW, "ESP", () -> cfg.espEnabled, v -> cfg.espEnabled = v);
        toggle(right, y, colW, "Scanner", () -> cfg.scannerEnabled, v -> cfg.scannerEnabled = v);
        y += step;
        toggle(left, y, colW, "Through walls", () -> cfg.throughWalls, v -> cfg.throughWalls = v);
        toggle(right, y, colW, "HUD panel", () -> cfg.showHud, v -> cfg.showHud = v);
        y += step;
        toggle(left, y, colW, "Distance labels", () -> cfg.showDistance, v -> cfg.showDistance = v);
        toggle(right, y, colW, "Coordinate labels", () -> cfg.showCoords, v -> cfg.showCoords = v);
        y += step;

        stepper(left, y, fullW, () -> "Radius: " + cfg.radius + " blocks", d -> {
            cfg.radius = Math.max(ModConfig.MIN_RADIUS, Math.min(ModConfig.MAX_RADIUS, cfg.radius + d * ModConfig.RADIUS_STEP));
            BlockScanner.requestRescan();
        });
        y += step;
        stepper(left, y, fullW, () -> String.format("Scan interval: %.2fs", cfg.scanIntervalTicks / 20.0), d -> {
            cfg.scanIntervalTicks = Math.max(ModConfig.MIN_INTERVAL, Math.min(ModConfig.MAX_INTERVAL, cfg.scanIntervalTicks + d * 5));
        });
        y += step;
        stepper(left, y, fullW, () -> "Scan up to Y = " + cfg.maxY, d -> {
            cfg.maxY = Math.max(ModConfig.MIN_Y, Math.min(ModConfig.MAX_Y, cfg.maxY + d * 10));
            BlockScanner.requestRescan();
        });
        y += step;

        for (Category c : Category.values()) {
            toggle(left, y, colW, c.label, () -> cfg.isEnabled(c), v -> {
                cfg.setEnabled(c, v);
                BlockScanner.requestRescan();
            });
            Button color = Button.builder(
                    Component.literal(String.format("Color: #%06X", cfg.color(c))),
                    b -> {
                        int cur = cfg.color(c);
                        int idx = 0;
                        for (int i = 0; i < PALETTE.length; i++) if (PALETTE[i] == cur) idx = i + 1;
                        cfg.setColor(c, PALETTE[idx % PALETTE.length]);
                        this.rebuildWidgets();
                    }).bounds(right, y, colW, 20).build();
            this.addRenderableWidget(color);
            y += step;
        }

        this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> this.onClose())
                .bounds(cx - 100, y + 6, 200, 20).build());
    }

    private void toggle(int x, int y, int w, String label, BooleanSupplier get, Consumer<Boolean> set) {
        Component text = Component.literal(label + ": " + (get.getAsBoolean() ? "ON" : "OFF"));
        this.addRenderableWidget(Button.builder(text, b -> {
            set.accept(!get.getAsBoolean());
            this.rebuildWidgets();
        }).bounds(x, y, w, 20).build());
    }

    private void stepper(int x, int y, int totalW, Supplier<String> label, IntConsumer change) {
        this.addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            change.accept(-1);
            this.rebuildWidgets();
        }).bounds(x, y, 20, 20).build());

        Button mid = Button.builder(Component.literal(label.get()), b -> {}).bounds(x + 22, y, totalW - 44, 20).build();
        mid.active = false;
        this.addRenderableWidget(mid);

        this.addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            change.accept(1);
            this.rebuildWidgets();
        }).bounds(x + totalW - 20, y, 20, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        graphics.text(this.font, this.title, this.width / 2 - this.font.width(this.title) / 2, 8, 0xFFFFFFFF, true);
    }

    @Override
    public void onClose() {
        ModConfig.save();
        BlockClassifier.clearCache();
        BlockScanner.requestRescan();
        this.minecraft.setScreen(parent);
    }
}
