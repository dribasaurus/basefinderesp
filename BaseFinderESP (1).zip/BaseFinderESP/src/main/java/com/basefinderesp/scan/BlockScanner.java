package com.basefinderesp.scan;

import com.basefinderesp.config.ModConfig;
import com.basefinderesp.detect.BlockClassifier;
import com.basefinderesp.detect.Category;
import com.basefinderesp.detect.Detection;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

/**
 * Client-side scanner. Runs on the client tick thread, only touches chunks the client already
 * has (ChunkStatus.FULL, no loading), skips empty/irrelevant sections via the palette check
 * (LevelChunkSection#maybeHas), rescans on an interval, and cheaply re-validates cached hits
 * in between so broken blocks disappear quickly.
 */
public final class BlockScanner {
    public record Row(Detection detection, double distance) {}

    private static final int MAX_DETECTIONS = 2000;

    private static volatile List<Detection> detections = List.of();
    private static volatile List<Row> rows = List.of();
    private static int ticksSinceScan = 0;
    private static boolean rescanRequested = true;

    private BlockScanner() {}

    public static List<Row> rows() { return rows; }
    public static int count() { return rows.size(); }
    public static void requestRescan() { rescanRequested = true; }

    public static void clear() {
        detections = List.of();
        rows = List.of();
        rescanRequested = true;
    }

    public static void tick(Minecraft mc) {
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        ModConfig cfg = ModConfig.get();

        if (level == null || player == null || !cfg.scannerEnabled) {
            if (!detections.isEmpty() || !rows.isEmpty()) clear();
            return;
        }

        ticksSinceScan++;
        if (rescanRequested || ticksSinceScan >= cfg.scanIntervalTicks) {
            ticksSinceScan = 0;
            rescanRequested = false;
            detections = scan(level, player, cfg);
            refreshRows(player);
        } else if (ticksSinceScan % 5 == 0) {
            validate(level);
            refreshRows(player);
        }
    }

    private static void validate(ClientLevel level) {
        List<Detection> current = detections;
        List<Detection> kept = new ArrayList<>(current.size());
        for (Detection d : current) {
            boolean stillThere = d.isEntity()
                    ? !d.entity().isRemoved()
                    : level.getBlockState(d.blockPos()).is(d.block());
            if (stillThere) kept.add(d);
        }
        if (kept.size() != current.size()) detections = kept;
    }

    private static void refreshRows(LocalPlayer player) {
        Vec3 p = player.position();
        List<Row> list = new ArrayList<>(detections.size());
        for (Detection d : detections) {
            list.add(new Row(d, p.distanceTo(d.center())));
        }
        list.sort(Comparator.comparingDouble(Row::distance));
        rows = list;
    }

    private static List<Detection> scan(ClientLevel level, LocalPlayer player, ModConfig cfg) {
        List<Detection> out = new ArrayList<>();
        int radius = cfg.radius;
        double r2 = (double) radius * radius;
        BlockPos pp = player.blockPosition();
        Vec3 pc = player.position();

        int minY = Math.max(level.getMinY(), pp.getY() - radius);
        int maxY = Math.min(Math.min(level.getMaxY(), cfg.maxY), pp.getY() + radius);

        Predicate<BlockState> interesting = state -> {
            BlockClassifier.Info info = BlockClassifier.classify(state.getBlock());
            return info.category() != null && cfg.isEnabled(info.category());
        };

        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        int pcx = pp.getX() >> 4, pcz = pp.getZ() >> 4;
        int cr = (radius >> 4) + 1;

        outer:
        for (int cx = pcx - cr; cx <= pcx + cr; cx++) {
            for (int cz = pcz - cr; cz <= pcz + cr; cz++) {
                // requireChunk=false: never triggers loading, returns null if the client doesn't have it.
                ChunkAccess chunk = level.getChunk(cx, cz, ChunkStatus.FULL, false);
                if (chunk == null) continue;

                LevelChunkSection[] sections = chunk.getSections();
                for (int i = 0; i < sections.length; i++) {
                    LevelChunkSection section = sections[i];
                    if (section.hasOnlyAir()) continue;
                    int baseY = (chunk.getMinSectionY() + i) << 4;
                    if (baseY + 15 < minY || baseY > maxY) continue;
                    if (!section.maybeHas(interesting)) continue;

                    for (int ly = 0; ly < 16; ly++) {
                        int y = baseY + ly;
                        if (y < minY || y > maxY) continue;
                        for (int lz = 0; lz < 16; lz++) {
                            for (int lx = 0; lx < 16; lx++) {
                                BlockState state = section.getBlockState(lx, ly, lz);
                                Block block = state.getBlock();
                                BlockClassifier.Info info = BlockClassifier.classify(block);
                                Category cat = info.category();
                                if (cat == null || !cfg.isEnabled(cat)) continue;

                                int x = (cx << 4) + lx;
                                int z = (cz << 4) + lz;
                                double dx = x + 0.5 - pc.x, dy = y + 0.5 - pc.y, dz = z + 0.5 - pc.z;
                                if (dx * dx + dy * dy + dz * dz > r2) continue;

                                if (isDuplicateHalf(level, mp, block, info.path(), x, y, z)) continue;

                                out.add(Detection.ofBlock(cat, block, mp.set(x, y, z)));
                                if (out.size() >= MAX_DETECTIONS) break outer;
                            }
                        }
                    }
                }
            }
        }

        if (cfg.isEnabled(Category.PLAYER) && out.size() < MAX_DETECTIONS) {
            for (Entity e : level.entitiesForRendering()) {
                EntityType<?> type = e.getType();
                if (type != EntityType.ITEM_FRAME && type != EntityType.GLOW_ITEM_FRAME && type != EntityType.ARMOR_STAND) {
                    continue;
                }
                if (e.getY() > cfg.maxY || e.distanceToSqr(pc) > r2) continue;
                out.add(Detection.ofEntity(Category.PLAYER, e));
                if (out.size() >= MAX_DETECTIONS) break;
            }
        }
        return out;
    }

    /** Doors and beds are two blocks; report only one half. */
    private static boolean isDuplicateHalf(ClientLevel level, BlockPos.MutableBlockPos mp, Block block,
                                           String path, int x, int y, int z) {
        if (path.endsWith("_door")) {
            return level.getBlockState(mp.set(x, y - 1, z)).is(block);
        }
        if (path.endsWith("_bed")) {
            // Keep the half whose horizontal partner has the larger (x, z); skip the other.
            if (level.getBlockState(mp.set(x - 1, y, z)).is(block)) return true;
            if (level.getBlockState(mp.set(x, y, z - 1)).is(block)) return true;
        }
        return false;
    }
}
