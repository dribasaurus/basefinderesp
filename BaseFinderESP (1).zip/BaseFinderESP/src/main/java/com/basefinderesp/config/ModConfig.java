package com.basefinderesp.config;

import com.basefinderesp.detect.Category;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** JSON config stored at .minecraft/config/basefinderesp.json */
public final class ModConfig {
    public static final int MIN_RADIUS = 8, MAX_RADIUS = 128, RADIUS_STEP = 8;
    public static final int MIN_INTERVAL = 5, MAX_INTERVAL = 200;
    public static final int MIN_Y = -64, MAX_Y = 320;

    private static final Logger LOG = LoggerFactory.getLogger("BaseFinderESP");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("basefinderesp.json");
    private static ModConfig instance = new ModConfig();

    public boolean espEnabled = true;
    public boolean scannerEnabled = true;
    public boolean throughWalls = true;
    public boolean showHud = true;
    public boolean showDistance = true;
    public boolean showCoords = true;

    public int radius = 64;
    public int scanIntervalTicks = 40;
    /** Only blocks at or below this Y level are scanned ("underground" filter). */
    public int maxY = 50;

    public Map<String, Boolean> categoryEnabled = new LinkedHashMap<>();
    /** "#RRGGBB" strings keyed by Category name. */
    public Map<String, String> categoryColor = new LinkedHashMap<>();
    /** Extra block IDs to flag as "Other suspicious" (path like "bookshelf" or "minecraft:bookshelf"). */
    public List<String> extraBlocks = new ArrayList<>(List.of("bookshelf", "jukebox", "lectern", "beacon", "flower_pot"));
    /** Block IDs that are never flagged. */
    public List<String> ignoredBlocks = new ArrayList<>();

    public static ModConfig get() {
        return instance;
    }

    public boolean isEnabled(Category c) {
        return categoryEnabled.getOrDefault(c.name(), true);
    }

    public void setEnabled(Category c, boolean value) {
        categoryEnabled.put(c.name(), value);
    }

    public int color(Category c) {
        String s = categoryColor.get(c.name());
        if (s != null) {
            try {
                return Integer.parseInt(s.replace("#", ""), 16) & 0xFFFFFF;
            } catch (NumberFormatException ignored) {
                // fall through to default
            }
        }
        return c.defaultColor;
    }

    public void setColor(Category c, int rgb) {
        categoryColor.put(c.name(), String.format("#%06X", rgb & 0xFFFFFF));
    }

    private void sanitize() {
        radius = Math.max(MIN_RADIUS, Math.min(MAX_RADIUS, radius));
        scanIntervalTicks = Math.max(MIN_INTERVAL, Math.min(MAX_INTERVAL, scanIntervalTicks));
        maxY = Math.max(MIN_Y, Math.min(MAX_Y, maxY));
        if (categoryEnabled == null) categoryEnabled = new LinkedHashMap<>();
        if (categoryColor == null) categoryColor = new LinkedHashMap<>();
        if (extraBlocks == null) extraBlocks = new ArrayList<>();
        if (ignoredBlocks == null) ignoredBlocks = new ArrayList<>();
    }

    public static void load() {
        if (Files.exists(PATH)) {
            try (Reader reader = Files.newBufferedReader(PATH)) {
                ModConfig loaded = GSON.fromJson(reader, ModConfig.class);
                if (loaded != null) {
                    loaded.sanitize();
                    instance = loaded;
                }
            } catch (Exception e) {
                LOG.warn("Could not read config, using defaults", e);
            }
        }
        save();
    }

    public static void save() {
        instance.sanitize();
        try (Writer writer = Files.newBufferedWriter(PATH)) {
            GSON.toJson(instance, writer);
        } catch (IOException e) {
            LOG.warn("Could not write config", e);
        }
    }
}
