package com.basefinderesp.detect;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** One flagged block or entity (item frame / armor stand). */
public final class Detection {
    public final Category category;
    public final String name;
    private final BlockPos pos;   // null for entities
    private final Block block;    // null for entities
    private final Entity entity;  // null for blocks

    private Detection(Category category, String name, BlockPos pos, Block block, Entity entity) {
        this.category = category;
        this.name = name;
        this.pos = pos;
        this.block = block;
        this.entity = entity;
    }

    public static Detection ofBlock(Category category, Block block, BlockPos pos) {
        return new Detection(category, block.getName().getString(), pos.immutable(), block, null);
    }

    public static Detection ofEntity(Category category, Entity entity) {
        return new Detection(category, entity.getType().getDescription().getString(), null, null, entity);
    }

    public boolean isEntity() { return entity != null; }
    public Entity entity() { return entity; }
    public Block block() { return block; }
    public BlockPos blockPos() { return entity != null ? entity.blockPosition() : pos; }
    public AABB box() { return entity != null ? entity.getBoundingBox() : new AABB(pos); }
    public Vec3 center() { return box().getCenter(); }
}
