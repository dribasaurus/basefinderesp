package com.basefinderesp.detect;

public enum Category {
    STORAGE("Storage", 0xFF3B3B),            // red
    UTILITY("Utility", 0xFF9F1A),            // orange
    PLAYER("Beds & player objects", 0xB04CFF), // purple
    OTHER("Other suspicious", 0x2DE2E6);     // cyan

    public final String label;
    public final int defaultColor;

    Category(String label, int defaultColor) {
        this.label = label;
        this.defaultColor = defaultColor;
    }
}
