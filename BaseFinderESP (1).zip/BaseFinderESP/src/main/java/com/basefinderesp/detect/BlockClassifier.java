package com.basefinderesp.detect;

import com.basefinderesp.config.ModConfig;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Classifies blocks by registry ID. Using IDs instead of Block subclasses keeps this
 * independent of vanilla class renames, and results are cached per Block instance.
 */
public final class BlockClassifier {
    /** category is null when the block is not interesting. */
    public record Info(Category category, String path) {}

    private static final Info NONE = new Info(null, "");
    private static final Map<Block, Info> CACHE = new IdentityHashMap<>();

    private static final Set<String> UTILITY = Set.of(
            "crafting_table", "furnace", "blast_furnace", "smoker",
            "anvil", "chipped_anvil", "damaged_anvil",
            "enchanting_table", "brewing_stand", "loom", "smithing_table");

    private BlockClassifier() {}

    public static Info classify(Block block) {
        Info info = CACHE.get(block);
        if (info == null) {
            info = compute(block);
            CACHE.put(block, info);
        }
        return info;
    }

    public static void clearCache() {
        CACHE.clear();
    }

    private static Info compute(Block block) {
        Identifier id = BuiltInRegistries.BLOCK.getKey(block);
        String path = id.getPath();
        String full = id.toString();
        ModConfig cfg = ModConfig.get();

        if (cfg.ignoredBlocks.contains(path) || cfg.ignoredBlocks.contains(full)) {
            return NONE;
        }

        Category c = null;
        if (path.equals("chest") || path.endsWith("_chest") || path.equals("barrel") || path.endsWith("shulker_box")) {
            c = Category.STORAGE;            // chest, trapped_chest, ender_chest, copper chests, barrel, shulkers
        } else if (UTILITY.contains(path)) {
            c = Category.UTILITY;
        } else if (path.endsWith("_bed")) {
            c = Category.PLAYER;
        } else if (path.endsWith("_door") || path.endsWith("_trapdoor") || path.endsWith("_sign")) {
            c = Category.OTHER;              // doors, trapdoors, standing/wall/hanging signs
        } else if (cfg.extraBlocks.contains(path) || cfg.extraBlocks.contains(full)) {
            c = Category.OTHER;              // user-defined "decorative" blocks
        }
        return c == null ? NONE : new Info(c, path);
    }
}
