package com.basefinderesp;

import com.basefinderesp.config.ModConfig;
import com.basefinderesp.detect.BlockClassifier;
import com.basefinderesp.gui.ConfigScreen;
import com.basefinderesp.render.EspRenderer;
import com.basefinderesp.render.HudOverlay;
import com.basefinderesp.scan.BlockScanner;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class BaseFinderEspClient implements ClientModInitializer {
    public static final String MOD_ID = "basefinderesp";
    private static final Logger LOG = LoggerFactory.getLogger("BaseFinderESP");

    /** Heuristic only: true if the launch command / classpath mentions Lunar. */
    public static boolean lunarSuspected;

    private static KeyMapping toggleEsp, toggleScanner, openMenu, radiusUp, radiusDown;

    @Override
    public void onInitializeClient() {
        ModConfig.load();
        BlockClassifier.clearCache();

        String launch = (System.getProperty("sun.java.command", "") + System.getProperty("java.class.path", "")).toLowerCase();
        lunarSuspected = launch.contains("lunar");
        if (lunarSuspected) {
            LOG.warn("Lunar Client appears to be in use. Lunar only loads Fabric mods it supports; "
                    + "BaseFinder ESP may not load or render there. Use a standard Fabric install if it does not.");
        }

        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
        toggleEsp = key("toggle_esp", GLFW.GLFW_KEY_H, category);
        toggleScanner = key("toggle_scanner", GLFW.GLFW_KEY_J, category);
        openMenu = key("open_menu", GLFW.GLFW_KEY_U, category);
        radiusUp = key("radius_up", GLFW.GLFW_KEY_RIGHT_BRACKET, category);
        radiusDown = key("radius_down", GLFW.GLFW_KEY_LEFT_BRACKET, category);

        ClientTickEvents.END_CLIENT_TICK.register(BaseFinderEspClient::onTick);
        EspRenderer.init();
        HudOverlay.init();
    }

    private static KeyMapping key(String name, int glfwKey, KeyMapping.Category category) {
        return KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key." + MOD_ID + "." + name, InputConstants.Type.KEYSYM, glfwKey, category));
    }

    private static void onTick(Minecraft client) {
        ModConfig cfg = ModConfig.get();
        boolean dirty = false;

        while (toggleEsp.consumeClick()) { cfg.espEnabled = !cfg.espEnabled; dirty = true; }
        while (toggleScanner.consumeClick()) { cfg.scannerEnabled = !cfg.scannerEnabled; BlockScanner.requestRescan(); dirty = true; }
        while (radiusUp.consumeClick()) { cfg.radius = Math.min(ModConfig.MAX_RADIUS, cfg.radius + ModConfig.RADIUS_STEP); BlockScanner.requestRescan(); dirty = true; }
        while (radiusDown.consumeClick()) { cfg.radius = Math.max(ModConfig.MIN_RADIUS, cfg.radius - ModConfig.RADIUS_STEP); BlockScanner.requestRescan(); dirty = true; }
        while (openMenu.consumeClick()) { client.setScreen(new ConfigScreen(client.screen)); }

        if (dirty) ModConfig.save();
        BlockScanner.tick(client);
    }
}
