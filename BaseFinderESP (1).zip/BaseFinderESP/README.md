# BaseFinder ESP (Fabric, Minecraft Java 26.1.2)

Client-side Fabric mod that flags unusual, player-placed blocks underground (storage, utility blocks,
beds, doors/trapdoors/signs, item frames, armor stands, plus a configurable extra list) and shows them
with colored through-wall outlines and a HUD panel.

> **Status: NOT compiled or tested.** This project was written without network access, so it was never built
> or run. Version numbers and API names were checked against the Fabric 26.1.2 docs and community sources,
> but a few calls are unconfirmed (see "Unverified spots"). Expect to fix a compile error or two.

## Requirements
- JDK 25
- Gradle 9.4 or newer (Loom for 26.1 requires it)
- Minecraft Java 26.1.2, Fabric Loader >= 0.19.1, Fabric API 0.150.0+26.1.2

## Build
```
gradle wrapper --gradle-version latest   # one-time: generates gradlew + wrapper jar
./gradlew build                          # Windows: gradlew.bat build
```
Output: `build/libs/BaseFinderESP.jar`. (The `-sources` jar next to it is not needed.)
To test in a dev client: `./gradlew runClient`.

## Install
Put `BaseFinderESP.jar` and the Fabric API jar into `.minecraft/mods` with a Fabric 26.1.2 profile.

## Controls (all rebindable in Options > Controls > Key Binds > BaseFinder ESP)
| Key | Action |
|---|---|
| H | Toggle ESP |
| J | Toggle scanner |
| U | Open config menu |
| ] / [ | Increase / decrease scan radius (steps of 8, range 8-128) |

## Config
`.minecraft/config/basefinderesp.json`: radius, scan interval, max Y ("underground" filter), category
toggles/colors (`"#RRGGBB"`), `extraBlocks` (extra decorative IDs to flag), `ignoredBlocks`.
Colors: red = storage, orange = utility, purple = beds + item frames + armor stands, cyan = doors,
trapdoors, signs and extra blocks.

## How scanning works
Every scan interval (default 2 s) it walks the chunks the client already has (never loads chunks), skips
sections whose palette has nothing interesting, and keeps a cache of hits. Between scans the cache is
re-validated every 5 ticks so broken blocks vanish. Capped at 2000 detections.

## Unverified spots (check these first if the build fails)
1. `render/EspRenderer.java`: `LevelRenderEvents.BEFORE_GIZMOS` callback parameters, `Gizmos.cuboid`,
   `GizmoStyle.strokeAndFill(int, float, int)`, `setAlwaysOnTop()` (names taken from community mods, not the Javadoc).
2. `scan/BlockScanner.java`: `LevelChunkSection#maybeHas/hasOnlyAir/getBlockState`, `chunk.getMinSectionY()`,
   `level.getMinY()/getMaxY()`, `level.entitiesForRendering()`.
3. Loom version `1.16.2` and Gradle requirement come from release notes/issues, not the official Loom page.

Known gaps: no floating in-world text labels (name/coords/distance are in the HUD list instead);
natural structures (mineshaft chests, strongholds, trial chambers, villages) will produce false positives.

## Lunar Client
Lunar only loads Fabric mods it explicitly supports, so this jar may not load there. The mod logs a warning
and shows a HUD warning if it detects Lunar. A standard Fabric profile is the reliable way to run it.
Through-wall ESP is against the rules of Lunar and many servers.

## Build without installing anything (GitHub Actions)
1. Create a free GitHub repo and upload this whole folder (including the hidden `.github` folder).
2. Open the repo's **Actions** tab, pick **Build BaseFinderESP**, and wait for it to finish
   (it also runs automatically on every push).
3. Open the finished run and download the **BaseFinderESP** artifact. Unzip it to get `BaseFinderESP.jar`.
If the run fails, the log shows the compile errors.
